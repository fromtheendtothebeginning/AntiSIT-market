# 来源与改动说明（2048）

* 上游：[gabrielecirulli/2048](https://github.com/gabrielecirulli/2048)
* 版本：`master` 分支，commit `478b6ec346e3787f589e4af751378d06ded4cbbc`（2026-10-18 取）
* 许可：MIT（见同目录 [`LICENSE.txt`](LICENSE.txt)，Copyright (c) 2014 Gabriele Cirulli）
* 本包是**改编版**，不是上游原样副本。

## 改了什么

1. **存储层换成 App 的接口**（上游 `js/local_storage_manager.js` → 本包 `js/ext_storage_manager.js`）：
   拓展页是 App 用 `loadHtmlString` 打开的，来源是 opaque origin，读 `window.localStorage`
   直接抛 SecurityError。上游虽有 try/catch 会退回内存版（游戏仍能开），但最高分关掉 App
   就没了。现在最高分走 `antiSIT.call('storage.get'/'storage.set')` 真正落盘，
   所以 `ext.json` 里声明了 `storage` 权限。顺带去掉「继续上局」那套棋局落盘
   （`getGameState()` 固定返回 null），每次打开都是新一局。
2. **手机版式**：上游是两套写死的版式（桌面 500px、≤520px 时 280px），改为按屏宽缩放
   （`min(440px, 88vw)`，几何比例与上游一致）。改动全部集中在 `style/main.css` 末尾的
   `@media (max-width: 560px)` 段落，上游原有规则未删。
3. **去掉外链与包外资源**：删掉 `@import url(fonts/clear-sans.css)`（7 个字体文件，改用系统
   字体栈）、`favicon.ico` 与 `meta/apple-touch-*.png` 的 `<link>`（App 里用不到）。
   市场装的拓展默认禁网，带这些外链会被 CSP 拦掉，也会被市场工具拦在投稿这一步。
4. **文案**：界面文案与游戏提示改为中文（`得分`/`最高`/`新游戏`/`你赢了！`/`游戏结束` 等），
   说明文字改成「滑动或方向键」。滑动手势是**上游自带**的
   （`js/keyboard_input_manager.js` 里 touchend 的手势识别），没有改动。
5. `index.html` 补了 `<meta name="viewport">`、`lang="zh-CN"`；底部的「官方版声明」换成
   指向上游仓库的署名（点开由系统浏览器打开，见 `docs/extensions.md` 的导航约定）。
6. **撤回**：`game_manager.js` 在每次有效移动后记一份「反向帧」（走之前的棋盘快照 +
   每个旧格子这一步从哪滑到哪 + 这一步新长出来 / 合并出来的格子），最多 20 步，只在内存里；
   新开一局清空。撤回时把棋盘恢复成快照，并给每个旧格子设 `previousPosition` = 这一步结束时的
   位置——渲染器会先画在结束位置，再靠原有的 100ms transform 过渡滑回原位，等于把正向滑动
   倒放一遍；合并出来的大格子和随机新格子则以 `tile-vanish` 原地缩小消失（正向 appear / pop
   的倒放）。`undo-button` 恢复分数、胜负状态并收掉「游戏结束 / 你赢了」浮层——踩死之后也能撤回。
   `html_actuator.js` 负责倒放与按钮压灰，`keyboard_input_manager.js` 绑了按钮和 Z / Ctrl+Z
   快捷键，`index.html` / `style/main.css` 加了按钮、样式与 vanish 动画。

## 未改动

`js/grid.js`、`js/tile.js`、`js/ext_storage_manager.js`、三个 polyfill 与 `style/main.css`
除上述之外的规则，都与上游一致（`js/html_actuator.js` 仅按第 4、6 条改文案与撤回按钮状态）。

## 2026-11 Cordis 迁移

* 市场运行时不支持旧 `index.html` 包，入口改为 Cordis 插件 `main.js`（`ext.json` 的
  `runtime: "cordis"`、`main: "main.js"`）；样式仍是 `style/main.css`。
* 原始 `index.html` 与 `js/` 移到 `_src/` 保留作维护源（`_src/` 不会打进 zip）；
  `main.js` 由这些源文件拼成，玩法代码未改。
* 存储从裸 `antiSIT.call` 改为 Cordis 的 `ctx.storage`；`permissions` 仍为 `storage`。
* 版本升到 `1.2.0`，`minAppVersion` 升到 `1.25.0`（Cordis 运行时从该版本开始）。
