# NOTICE

本拓展是 AntiSIT 的原创实现（GPL-3.0-only），不含第三方代码。

为了让插件能在没有证书的校内站点上工作，它使用了两项 App 提供的能力：

* `ctx.net.campus`（App ≥ 1.44.0）：校内明文 http 通道，服务器模式下自动经校园隧道代理；
* `ctx.secrets` / `ctx.notify`：加密凭据与系统通知。

学校登录页把密码用 AES-128-ECB（固定口令，见页面 `BaseInfo/Login.js` 的 `Encrypt3`）
处理后再做一次 base64，本拓展自带了一份最小的 AES-128-ECB 实现来完成这个变换；
它只处理用户自己输入的密码，不上传、不落盘。

页面里没有任何学校账号、密码或学号样例。
